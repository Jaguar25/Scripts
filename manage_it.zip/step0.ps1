﻿$computerName = Get-WmiObject Win32_ComputerSystem
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
$name = [Microsoft.VisualBasic.Interaction]::InputBox("Enter new Computer Name")
$computername.rename("$name")
Restart-Computer
