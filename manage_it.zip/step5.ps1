﻿Write-Host "Migrate M2K toolbar and ini files"
$oldcomputername = read-host "Please enter old computer name."

$windowsversion = gwmi win32_operatingsystem | select name


if ($windowsversion -match 'Windows 7')
{
Write-Host "Windows 7"
 $sourceM2K = "\\" + $oldcomputername + "\C$\Program Files\ROI Systems\PWS\TOOLBAR.TBX"
 $destinationM2K =  "C:\Program Files (x86)\ROI Systems\PWS\"
 Copy-Item -Path $sourceM2K -Destination $destinationM2K
 $sourceM2KPWSMACROini = "\\" + $oldcomputername + "\C$\WINDOWS\PWSMACRO.INI"
 $sourceM2KPWSWINini = "\\" + $oldcomputername + "\C$\WINDOWS\PWSWIN.INI"
 $sourceM2KPWSCOMini = "\\" + $oldcomputername + "\C$\WINDOWS\PWSCOM.INI"
  
 $destinationM2KPWSMACROini =  "C:\WINDOWS\"
 $destinationM2KPWSWINini =  "C:\WINDOWS\"
 $destinationM2KPWSCOMini =  "C:\WINDOWS\"
 
 Copy-Item -Path $sourceM2K -Destination $destinationM2K
 Copy-Item -Path $sourceM2KPWSMACROini -Destination $destinationM2KPWSMACROini
 Copy-Item -Path $sourceM2kPWSWINini -Destination $destinationM2KPWSWINini
 Copy-Item -Path $sourceM2KPWSCOMini -Destination $destinationM2KPWSCOMini

 $TargetPath="C:\Program Files (x86)\ROI Systems\PWS\PWSWin32.exe" 
 $WshShell = New-Object -ComObject WScript.Shell
 $Shortcut = $WshShell.CreateShortcut("C:\Users\Public\Desktop\M2k.lnk")
 $Shortcut.TargetPath = $TargetPath
 $Shortcut.Description="Restek's ERP"
 $Shortcut.Arguments="untitled.cnf"
 $Shortcut.WorkingDirectory="C:\Program Files (x86)\ROI Systems\PWS"
 $Shortcut.Save()
 $sourceM2K = "\\mickey\Programs\pwslatest\config\untitled.cnf"
 $destinationM2K =  "C:\Program Files (x86)\ROI Systems\PWS"
 Copy-Item -Path $sourceM2K -Destination $destinationM2K | Out-Host
  
}
elseif ($windowsversion -match 'XP')
{ 
Write-Host "Windows XP"
} 
