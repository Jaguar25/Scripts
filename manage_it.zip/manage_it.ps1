﻿[BOOLEAN]$global:xExitSession=$false


function LoadMenu()
{
 [int]$MenuChoice = 0
  while ( $MenuChoice -lt 1 -or $MenuChoice -gt 99 ) {
  CLS
    Write-Host "____________________________________________________________ "
    Write-Host "             Please select necessary step                    "
    Write-Host "____________________________________________________________ "
    Write-Host "     1. Rename Machine (reboot)" -fore DarkCyan
    Write-Host "     2. Join Machine to the Domain (reboot)" -fore DarkCyan
    Write-Host "     3. Machine configuration" -fore DarkCyan
    Write-Host "     4. Migration from old machine" -fore DarkCyan
    Write-Host "     5. Software Installation" -fore DarkCyan
    Write-Host "     6. M2K Cleanup (after manual install of M2K)" -fore DarkCyan
    Write-Host "     7. Copy Office UI  **User must be logged in!!**" -fore DarkCyan
    Write-Host "     99. Exit" -fore Red
    Write-Host "____________________________________________________________ "
    


  [Int]$MenuChoice = Read-Host "                         Please select #step to proceed"
 }
  CLS

  Switch ($MenuChoice)
 {

  1 
    { 
     Write-Host "OK, Restarting Machine. Please Note - Machine will RESTART"
    .\step0.ps1
    }

  2 
    {
     Write-Host "OK, Joining to the domain. Please Note - Machine will RESTART"
     .\step1.ps1
    }
  3 
    {
     Write-Host "OK, Changing machine's configuration"
     .\step2.ps1
    }

  4 
    {
     Write-Host "Ok, Migrating User to a new and shiny PC"
     .\step3.ps1
    }

  5
    {
    Write-Host "Ok, Non-Standard Software Installation"
    .\step4.ps1
    } 

  6
    {
    Write-Host "Ok, Scripting is fun "
    .\step5.ps1
    } 

  7 {
    Write-Host "Ok, calling Office UI copy"
    .\OfficeUI.ps1
    }
     

  99
    {
     Write-Host "Ok, i will exit now"
     $global:xExitSession=$true;break
     Exit-PSSession 
    }


  }

}

LoadMenu

if ($xExitSession)
 {
  Exit-PSSession
 }
 Else
 {
 .\manage_it.ps1
 }
