﻿####################################################################
#
# Function Declarations
#
####################################################################


function copyOfficeQuickAccessToolbar{

    # Get version of Office using Excel Application version.  Returns 14.0, 15.0, 16.0 etc.
    $objExcel = New-Object -ComObject Excel.Application
    $officeVersion = $objExcel.Version
    echo "Office version = $officeVersion"

    # Test which version of office and copy the appropriate quick access UI shortcuts
    try
    {
        if ($officeVersion -match 16.0){

            $sourcePath = 'C:\Scripts\Office_UI\Office_2016_UI\'
            Get-ChildItem -Path $sourcePath -Filter *.officeUI | Copy-Item -Destination $officePathUI
            echo "Copied Office 2016 UI toolbar quick access shortcuts"

        } elseif ($officeVersion -match 15.0) {

            $sourcePath = 'C:\Scripts\Office_UI\Office_2013_UI\'
            Get-ChildItem -Path $sourcePath -Filter *.officeUI | Copy-Item -Destination $officePathUI
            echo "Copied Office 2013 UI toolbar quick access shortcuts"

        } elseif ($officeVersion -match 14.0) {

            $sourcePath = 'C:\Scripts\Office_UI\Office_2010_UI\'
            Get-ChildItem -Path $sourcePath -Filter *.officeUI | Copy-Item -Destination $officePathUI
            echo "Copied Office 2010 UI toolbar quick access shortcuts"

        } else {

            echo "No Office version found"

        }
    }
    catch
    {
       $_.Exception.Message | Out-File C:\Scripts\error.log -Append   
       Break 
    }

  }

####################################################################
#
# Begin Main Program
#
####################################################################

$currentUser = [Environment]::UserName
$computerName = $env:computername

echo "Computer Name = $computerName"
echo "User Name = $currentUser"

# User - Office Path Variable
$officePathUI = '\\' + "$computerName" + '\C$\Users\' + "$currentUser" + '\AppData\Local\Microsoft\Office'

# Check if <username> is C:\Users\<username> or C:\Users\<username>.RESTECORP
if(Test-Path $officePathUI){

    echo "$currentUser Exists without .RESTEKCORP"

    try
    {
        copyOfficeQuickAccessToolbar -ErrorAction Stop
    }
    catch
    {
        $_.Exception.Message | Out-File C:\Scripts\error.log -Append
        Break        
    }


} else {

        echo "$currentUser  does not Exist, checking with RESTEKCORP"
        $officePathUI = '\\' + "$computerName" + '\C$\Users\' + "$currentUser" + ".restekcorp" + '\AppData\Local\Microsoft\Office'

        if(Test-Path $officePathUI){

            echo "$currentUser.RESTEKCORP exists."

            try
            {
                copyOfficeQuickAccessToolbar -ErrorAction Stop
            }
            catch
            {
                $_.Exception.Message | Out-File C:\Scripts\error.log -Append   
                Break     
            }

        } else {

            echo "User does not exist at all!"

        }
}



  